#ifndef __INC_FASTLED_ARM_SAM_H
#define __INC_FASTLED_ARM_SAM_H

// Include the sam headers
#include "fastpin_arm_sam.h"
#include "fastspi_arm_sam.h"
#include "clockless_arm_sam.h"
#include "clockless_block_arm_sam.h"

#endif
